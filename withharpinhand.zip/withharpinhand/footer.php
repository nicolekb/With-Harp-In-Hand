<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package withharpinhand
 */

?>

	<footer>
		<div class="container">
			<div class="col-sm-6">
				<?php
					wp_nav_menu( array(
						
						'theme_location'	=> 'footer',
						'container'			=> 'nav',
						'menu_class'		=> 'list-unstyled list-inline'
						
					) );
				?>
			</div><!-- end col -->
		</div><!-- container -->
	</footer>

	</body>
</html>
