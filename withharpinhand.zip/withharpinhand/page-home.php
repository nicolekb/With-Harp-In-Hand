<?php
/*
	Template Name: Home Page	
*/

get_header(); ?>

<?php get_template_part('content','hero'); ?>

<?php get_footer(); ?>