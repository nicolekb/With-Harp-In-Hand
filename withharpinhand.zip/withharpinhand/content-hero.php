<?php 
	// Custom Fields
	$banner_text			= get_field('banner_text');
	$banner_subtitle		= get_field('banner_subtitle');
	$harp_music_button		= get_field('harp_music_button');
	$harp_therapy_button	= get_field('harp_therapy_button');
?>

<!-- HERO
================================================== -->
<section id="hero" data-type="background" data-speed="5">
	<article>
		<div class="container clearfix">
			<div class="row">
				
				<!-- <img src="<?php echo $header_banner['url']; ?>" alt=""> -->
				
				<div class="col-sm-7 hero-text">
					<h1><?php bloginfo('name'); ?></h1>
					
					<p><?php echo $banner_text; ?></p>
					<h2><?php echo $banner_subtitle; ?></h2>
					
					<p><a class="btn btn-lg btn-danger" href="<?php echo $harp_music_button; ?>" role="button"><?php echo $harp_music_button; ?></a></p>

					<p><a class="btn btn-lg btn-danger" href="<?php echo $harp_therapy_button; ?>" role="button"><?php echo $harp_therapy_button; ?></a></p>
					
				</div><!-- col -->
				
			</div><!-- row -->
		</div><!-- container -->
	</article>
</section><!-- hero -->